import logo from './logo.svg';
import './App.css';
import {Route, Routes } from 'react-router-dom';
/*Importação dos componentes:*/
import Header from './components/Header';
import Footer from './components/Footer';
/*Importação das páginas: */
import Home from './pages/Home';
import CadastroEvento from  './pages/CadastroEvento';
import ListaEventos from './pages/ListaEventos'; // importação da página criada na segunda versão
import Disponiveis from './pages/Disponiveis';

function App() {
  return (
    <div className="app">
      <Header />

      <main>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/cadastro" element={<CadastroEvento />} />
          <Route path="/lista" element={<ListaEventos />} />
          <Route path="/disponiveis" element={<Disponiveis />} />

        </Routes>
     
      </main>
      
      <Footer />
    </div>
  );
}

export default App;
