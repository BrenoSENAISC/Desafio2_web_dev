import React from "react";
import './CadastroEvento.css';  //importação do arquivo CadastroEvento.css criado nesse segunda versão
import react, { useEffect, useState } from "react";




/* Primeira versão: */
/*
function CadastroEvento() {
    return (
        <div>
            <h1>Página Cadastro</h1>
        </div>
    )
}
*/
function CadastroEvento() {
    const [evento, setEvento] = useState({
        placa: '',
        proprietario: '',
        apto: '',
        bloco: '',
        veiculo: '',
        cor: '',
        vaga: ''
    });
    
    const handleInputChange = (event) => {
        const { name, value} = event.target;
        setEvento({...evento, [name]: value});
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        //Validação dos campos para evitar o envio de dados inválidos
        if (!evento.placa || !evento.proprietario || !evento.apto || !evento.bloco || !evento.veiculo || !evento.cor || !evento.vaga) {
            alert('Preencha todos os campos!');
            return;
        }

        //Recupera os eventos já cadastrados no LocalStorage
        const eventosCadastrados = JSON.parse(localStorage.getItem('eventos')) || [];

            //Adiciona o novo evento a lista de eventos
            eventosCadastrados.push(evento);

            //Atualiza o LocalStorage com a lista de eventos atualizada
            localStorage.setItem('eventos', JSON.stringify(eventosCadastrados));

            //Limpa os campos após o cadastro
            setEvento({
                placa: '',
                proprietario: '',
                apto: '',
                bloco: '',
                veiculo: '',
                cor: '',
                vaga: ''

            });
            
            alert('Evento cadastrado com sucesso!')
            console.log(evento.placa, evento.proprietario, evento.bloco, evento.veiculo, evento.cor, evento.vaga);
    }

 


return (
    <div>
        <h1>Cadastro de Evento</h1>
        <form onSubmit={handleSubmit}> 
            <label>Placa do veiculo:</label>
            <input type="text" name="placa" value={evento.placa} onChange={handleInputChange} />

            <label>Nome do proprietário:</label>
            <input type="text" name="proprietario" value={evento.descricao} onChange={handleInputChange} />

            <label>Número do apartamento:</label>
            <input type="text" name="apto" value={evento.data} onChange={handleInputChange} />

            <label>Número do bloco:</label>
            <input type="text" name="bloco" value={evento.local} onChange={handleInputChange} />

            <label>Modelo do Veículo:</label>
            <input type="text" name="veiculo" value={evento.local} onChange={handleInputChange} />

            <label>Cor do Veículo:</label>
            <input type="text" name="cor" value={evento.local} onChange={handleInputChange} />

            <label>Número da Vaga:</label>
            <input type="text" name="vaga" value={evento.local} onChange={handleInputChange} />

            <button type="submit">Incluir</button>
        </form>
    </div>
);
}
export default CadastroEvento;