import React from "react";

function Disponiveis() {
    return (
        <div>
            <h1>Lista de vagas disponiveis.</h1>   
            <section>
                <div class="container">
                    <div class="vagaLivre">1023 Livre</div>
                    <div class="vagaLivre">1052 Livre</div>
                    <div class="vagaOcupada">105 Ocupada</div>
                    <div class="vagaLivre">1083 Livre</div>
                    <div class="vagaOcupada">133 Ocupada</div>
                    <div class="vagaLivre">1023 Livre</div>
                    <div class="vagaLivre">1052 Livre</div>
                    <div class="vagaOcupada">207 Ocupada</div>          

                </div>
                <div>
                <h3>
                      ==== ===  Acesso  Principal ===  ===    Rua A  ====
                </h3>

                <div class="container">
                    <div class="vagaLivre">1053 Livre</div>
                    <div class="vagaLivre">1072 Livre</div>
                    <div class="vagaOcupada">701 Ocupada</div>
                    <div class="vagaOcupada">702 Ocupada</div>
                    <div class="vagaLivre">1093 Livre</div>
                    <div class="vagaLivre">1123 Livre</div>
                    <div class="vagaLivre">1152 Livre</div>
                    <div class="vagaOcupada">90 Ocupada</div>  
                </div>
                
                <h3>
                    ==== ===  Acesso  Secundário ===  ===    Rua B  ====
                </h3>
                <p>*Observação: Protótipo de apresentação de vagas para ser redimensionado posteriormente conforme quantidade de vagas.</p>
            </div>
                
            </section>         
        </div>
        
    )
}

export default Disponiveis;