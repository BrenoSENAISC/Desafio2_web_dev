import React from "react";

function Home() {
    return (
        <div>
            <h1>Você está na páginaHome do controle de estacionamento.</h1>
            <h3>Seja bem vindo ao Controle desafio 2 de Estacionamento!</h3>
        </div>
    )
}

export default Home;