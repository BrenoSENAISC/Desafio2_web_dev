/*Na primeira versão não tinha esse arquivo (ListaEventos.js) */
import React from "react";

function ListaEventos() {
    /*A seguir, será armazenado na variável eventos tudo que for encontrado no local storage (localmente no navegador do usuário)
    mas que tiver item 'eventos'. Se nada for encontrado, será retornado array vazio, que é a parta  final  "[]' da linha seguinte" */
    const eventos = JSON.parse(localStorage.getItem('eventos')) || [];

    /*   A seguir, a função map percorre eventos e vai retornando uma lista em li com atributo key 
                e adicionando os parâmetros título descrição data e local */
    return (

        <div>
             <h1> Vagas cadastradas</h1>

            <table>
                <thead>
                    <tr>
                        <th>Placa</th>
                        <th>Proprietário</th>
                        <th>Apartamento</th>
                        <th>bloco</th>
                        <th>Modelo Veículo</th>
                        <th>Cor Veículo</th>
                        <th>Vaga</th>
                        <th>Observação</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>GPJ3053</td>
                        <td>Eça de Queiroz</td>
                        <td>203</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>105</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>BCG30H32</td>
                        <td>Lobato</td>
                        <td>102</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>202</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>JJJ30T12</td>
                        <td>Saramago</td>
                        <td>204</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>90</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>AKA3055</td>
                        <td>Lins</td>
                        <td>615</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>31</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>BLCD30J34</td>
                        <td>Augusto do Anjos</td>
                        <td>303</td>
                        <td>bloco G</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>133</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>HNM30K23</td>
                        <td>Cecília</td>
                        <td>502</td>
                        <td>bloco A</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>121</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>NEM00B11</td>
                        <td>Mário de Andrade</td>
                        <td>101</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>152</td>
                        <td>Locatário</td>
                    </tr>

                    <tr>
                        <td>AKO4069</td>
                        <td>Azevedo</td>
                        <td>103</td>
                        <td>bloco C</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>133</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>SQL1000</td>
                        <td>Gregório de Matos</td>
                        <td>602</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>200</td>
                        <td>Locatário</td>
                    </tr>

                    <tr>
                        <td>JAV12P45</td>
                        <td>Mário Lago</td>
                        <td>701</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>207</td>
                        <td>Proprietário</td>
                    </tr>

                    <tr>
                        <td>MAG9090</td>
                        <td>José de Alencar</td>
                        <td>702</td>
                        <td>bloco B</td>
                        <td>Tempra 16 Válvulas</td>
                        <td>Vermelho</td>
                        <td>204</td>
                        <td>Proprietário</td>
                    </tr>
                </tbody>
            </table>

            





           
           
        </div>
    )
}

export default ListaEventos;