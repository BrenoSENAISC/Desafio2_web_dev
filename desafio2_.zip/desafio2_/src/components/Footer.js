import React from "react";

function footer() {
    return (
        <footer>
            <p>Desafio 2 Contato: controle_estacionamento_com_react_Desafio2@breno.cirilo.diniz.carvalho.lab</p>
        </footer>
    );
}

export default footer;
