import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './index.css';


ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>,      /*ATENÇÃO pois tem uma vírgula ao final da linha e ela não está sobrando! se tirar dá um bug tremendo!!! */

  document.getElementById('root')

);
